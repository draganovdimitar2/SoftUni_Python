def cat():
    return None